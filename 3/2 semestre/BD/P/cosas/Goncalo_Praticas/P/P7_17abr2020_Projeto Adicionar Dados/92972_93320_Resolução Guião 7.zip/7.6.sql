--create schema GestaoEscola;

CREATE TABLE GestaoEscola.Pessoa(
	NMec						INT				NOT NULL		CHECK(NMec> 0),
	nome						VARCHAR(30)		NOT NULL,
	telemovel					INT             UNIQUE,
	email						VARCHAR(30)     UNIQUE,
	PRIMARY KEY (NMec),
);

CREATE TABLE GestaoEscola.Funcionario(
	NMec						INT				NOT NULL		CHECK(NMec> 0),
	salario						MONEY			NOT NULL		CHECK(salario >0),
	PRIMARY KEY(NMec),
	FOREIGN KEY(NMec)			REFERENCES GestaoEscola.Pessoa(NMec)
);

CREATE TABLE GestaoEscola.Turno(
	codigo						INT				NOT NULL,
	horaInicio					TIME			NOT NULL,
	horaFim						TIME			NOT NULL,
	PRIMARY KEY(codigo),
--	UNIQUE(horaInicio), --confirmar estes uniques??
--	UNIQUE(horaFim)
-- Eu tirava estes uniques pq podem haver dois turnos a começar à mesma hora, mas a acabar a horas diferentes, não? A não ser que o UNIQUE se possa aplicar aos dois em simultâneo. Gonçalo
);

CREATE TABLE GestaoEscola.NaoDocente(
	NMec						INT				NOT NULL		CHECK(NMec> 0),
	turno						INT,
	PRIMARY KEY(NMec),
	FOREIGN KEY(NMec)			REFERENCES GestaoEscola.Pessoa(NMec),
	FOREIGN KEY(turno)			REFERENCES GestaoEscola.Turno(codigo)
);

CREATE TABLE GestaoEscola.BlocoTipo(
	codigo						INT				NOT NULL		CHECK(codigo >0),
	nome						VARCHAR(15)		NOT NULL,
	PRIMARY KEY(codigo)
);

CREATE TABLE GestaoEscola.ND_Funcao(
	codigo						INT				NOT NULL		CHECK(codigo > 0),
	nome						VARCHAR(15)		NOT NULL,
	PRIMARY KEY(codigo)
);

CREATE TABLE GestaoEscola.Bloco(
	coordenadas					VARCHAR(15)		NOT NULL,
	nome						VARCHAR(15)		NOT NULL,
	tipo						INT,
	supervisor					INT,
	PRIMARY KEY(coordenadas),
	FOREIGN KEY(tipo)			REFERENCES	GestaoEscola.BlocoTipo(codigo),
	FOREIGN KEY(supervisor)		REFERENCES	GestaoEscola.NaoDocente(NMec)
);

CREATE TABLE GestaoEscola.ND_trabalha_Bloco(
	Bcoordenadas				VARCHAR(15),
	NMec						INT,
	codFuncao					INT,
	horaInicio					TIME			NOT NULL,
	horaFim						TIME			NOT NULL,
	PRIMARY KEY(Bcoordenadas,NMec),
	FOREIGN KEY(codFuncao)		REFERENCES	GestaoEscola.ND_Funcao(codigo),
	FOREIGN KEY(Bcoordenadas)	REFERENCES	GestaoEscola.Bloco(coordenadas),
	FOREIGN KEY(NMec)			REFERENCES	GestaoEscola.NaoDocente(NMec),
);

CREATE TABLE GestaoEscola.Sala(
	numero						INT				NOT NULL		CHECK(num > 0),
	blocoCoord					VARCHAR(15),
	PRIMARY KEY(numero),
	FOREIGN KEY(blocoCoord)		REFERENCES GestaoEscola.Bloco(coordenadas)
);

CREATE TABLE GestaoEscola.GrupoDisciplinar(
	num							INT				NOT NULL		CHECK(num > 0),
	nome    				    VARCHAR(20)		NOT NULL        UNIQUE,
	PRIMARY KEY(num),
);

CREATE TABLE GestaoEscola.Disciplina(
    codigo                      INT             NOT NULL,
    nome                        VARCHAR(30)     NOT NULL,
    grupoDisciplinar            INT             NOT NULL,
    PRIMARY KEY(codigo)
    FOREIGN KEY(grupoDisciplinar) REFERENCES GestaoEscola.GrupoDisciplinar(num),
)

CREATE TABLE GestaoEscola.AnoLetivo(
    codigo                      INT             NOT NULL,
    dataInicio                  DATE            NOT NULL,
    dataFim                     DATE            NOT NULL,
    PRIMARY KEY(codigo),
    CHECK(dataInicio<dataFim)
);

CREATE TABLE GestaoEscola.Turma(
	nivel						INT				NOT NULL		CHECK(nivel > 0),
	nome						VARCHAR(5)		NOT NULL        UNIQUE,
	diretorDeTurma				INT,
	anoLetivo                   INT,
	PRIMARY KEY(nivel,nome, anoLetivo),
	FOREIGN KEY(anoLetivo) REFERENCES GestaoEscola.AnoLetivo(codigo),
	FOREIGN KEY(diretorDeTurma)	REFERENCES GestaoEscola.Docente(NMec)
);

CREATE TABLE GestaoEscola.Anuncio(

	turmaNivel					INT,
	turmaNome					VARCHAR(5),
	anoLetivo                   INT,
	[data]						DATE			NOT NULL,
--  Pq é que data está entre parêntesis retos? Gonçalo
	hora						TIME			NOT NULL,
	docente						INT
	assunto						VARCHAR(30),
	mensagem					VARCHAR(150),
	PRIMARY KEY (turmaNivel,turmaNome, anoLetivo, docente, hora)
-- O que achas desta Foreign Key? Gonçalo
	FOREIGN KEY(turmaNivel, turmaNome, anoLetivo)	REFERENCES GestaoEscola.Turma(nivel, nome, anoLetivo),
	FOREIGN KEY(docente)	REFERENCES GestaoEscola.Docente(NMec)
);

CREATE TABLE GestaoEscola.Aula(
	sala						INT,
	horaInicio					TIME			NOT NULL,
	horaFim						TIME			NOT NULL,
	diaSemana					INT             NOT NULL, -- TODO Perceber como se implementam multivalue
	disciplina					INT             NOT NULL, -- TODO Relacionar c/ entidade quando criada
	docente						INT,
	nomeTurma					VARCHAR(5),
	nivelTurma					INT,
	anoLetivo                   INT,
	PRIMARY KEY(sala, horaInicio,horaFim)
	FOREIGN KEY(sala)       REFERENCES GestaoEscola.Sala(numero)
	FOREIGN KEY(disciplina) REFERENCES GestaoEscola.Disciplina(codigo)
	FOREIGN KEY(turmaNivel, nomeTurma, anoLetivo)	REFERENCES GestaoEscola.Turma(nivel, nome, anoLetivo),
	FOREIGN KEY(docente)	REFERENCES GestaoEscola.Docente(NMec)
);

CREATE TABLE GestaoEscola.Docente(
	NMec						INT				NOT NULL		CHECK(NMec> 0),
	grupoDisciplinar			INT,
	PRIMARY KEY(NMec),
	FOREIGN KEY(NMec)			REFERENCES GestaoEscola.Pessoa(NMec),
	FOREIGN KEY(grupoDisciplinar) REFERENCES GestaoEscola.GrupoDisciplinar(num)
);


CREATE TABLE GestaoEscola.Estudante(
	NMec						INT				NOT NULL		CHECK(NMec> 0),
	NomeEE						VARCHAR(20)		NOT NULL,
	contactoEE					INT,
	EmailEE 					VARCHAR(20),
	PRIMARY KEY (NMec),
	FOREIGN KEY(NMec)			REFERENCES GestaoEscola.Pessoa(NMec)
);

CREATE TABLE GestaoEscola.EstudanteTurma(
    estudanteNMec               INT             NOT NULL,
    turmaNivel                  INT             NOT NULL,
    turmaNome                   VARCHAR(5)      NOT NULL,
    anoLetivo                   INT             NOT NULL,
    PRIMARY KEY(estudanteNMec, turmaNivel, turmaNome, anoLetivo),
    FOREIGN KEY(estudanteNMec) REFERENCES GestaoEscola.Estudante(NMec),
    FOREIGN KEY(turmaNivel, turmaNome, anoLetivo)		REFERENCES GestaoEscola.Turma(nivel, nome, anoLetivo)
)

CREATE TABLE GestaoEscola.Recado(
	estudanteNMec				INT             NOT NULL,
	docenteNMEC 				INT             NOT NULL,
	data						DATETIME		NOT NULL,
	assunto						VARCHAR(30)     NOT NULL,
	mensagem					TEXT            NOT NULL,
	PRIMARY KEY(data,estudanteNMec,docenteNMEC,assunto)
	FOREIGN KEY(docenteNMEC)	REFERENCES GestaoEscola.Docente(NMec)
	FOREIGN KEY(estudanteNMec)	REFERENCES GestaoEscola.Estudante(NMec)
);

CREATE TABLE GestaoEscola.Biblioteca(
	nome						VARCHAR(20)		NOT NULL,
	horaAbertura				TIME			NOT NULL,
	horaEncerramento			TIME,
	supervisor                  INT,
	FOREIGN KEY(supervisor)		REFERENCES	GestaoEscola.NaoDocente(NMec),
	PRIMARY KEY(nome)
);

CREATE TABLE GestaoEscola.Livro(
	referencia					INT 			NOT NULL,
	ISBN						INT				NOT NULL,
	titulo						VARCHAR(30)		NOT NULL,
	autores						VARCHAR(50)		NOT NULL,
	-- não ficava melhor TEXT? É que 50 podem não chegar, n sei. Gonçalo
	biblioteca					VARCHAR(20),
	PRIMARY KEY(referencia),
	UNIQUE(ISBN),
	FOREIGN KEY(biblioteca)		REFERENCES GestaoEscola.Biblioteca(nome)
);

CREATE TABLE GestaoEscola.Requisicao(
	livro					    INT,
	biblioteca					VARCHAR(20),
	pessoaNMec  				INT,
	dataRequisicao				DATE			NOT NULL,
	dataEntrega					DATE			NOT NULL,
	PRIMARY KEY(biblioteca, livro, dataRequisicao),
	FOREIGN KEY(biblioteca)		REFERENCES GestaoEscola.Biblioteca(nome)
	FOREIGN KEY(livro)		    REFERENCES GestaoEscola.Livro(referencia)
	FOREIGN KEY(pessoaNMec)	    REFERENCES GestaoEscola.Pessoa(NMec)
	CHECK(dataEntrega < dataRequisicao)
);

CREATE TABLE GestaoEscola.ND_trabalha_Biblioteca(
	biblioteca  				VARCHAR(20),
	NMec						INT,
	codFuncao					INT,
	horaInicio					TIME			NOT NULL,
	horaFim						TIME			NOT NULL,
	PRIMARY KEY(biblioteca, NMec),
	FOREIGN KEY(codFuncao)		REFERENCES	GestaoEscola.ND_Funcao(codigo),
	FOREIGN KEY(biblioteca)	    REFERENCES	GestaoEscola.Biblioteca(nome),
	FOREIGN KEY(NMec)			REFERENCES	GestaoEscola.NaoDocente(NMec),
);