--- Exercício 7.5
--- Guião prático 7
--- Maria Inês 93320 e Gonçalo Matos 92972

--------------------------------------------------------------- 

-- a) i)
CREATE VIEW TitleAuthor(title, aufname, aulname) AS
SELECT titles.title, authors.au_fname, authors.au_lname
FROM (
	(dbo.titles JOIN dbo.titleauthor 
		ON titles.title_id=titleauthor.title_id) JOIN dbo.authors
			ON titleauthor.au_id=authors.au_id
)

-- a) ii)
CREATE VIEW PublishersExmployees(pubname, empfname, emplname) AS
SELECT publishers.pub_name, employee.fname, employee.lname
FROM (
	dbo.publishers JOIN dbo.employee
		ON publishers.pub_id=employee.pub_id
)


-- a) iii)
CREATE VIEW StoresTitlesSold(storname, title) AS
SELECT stores.stor_name, titles.title
FROM (
	(dbo.stores JOIN dbo.sales
		ON stores.stor_id=sales.stor_id) JOIN dbo.titles
			ON sales.title_id=titles.title_id
)

-- a) iv)
CREATE VIEW TitlesBusiness AS
SELECT *
FROM dbo.titles
WHERE titles.type LIKE 'business'

--------------------------------------------------------------- 

--- b)

-- i) Mostrar o número de autores para cada título
SELECT title, COUNT(aufname) AS authorsNumber
FROM TitleAuthor
GROUP BY title

-- ii) Mostrar o número de autores para cada publicação
SELECT pubname, COUNT(empfname) AS authorsNumber
FROM PublishersExmployees
GROUP BY pubname

-- iii) Número de lojas em que cada título é vendido
SELECT title, COUNT(storname) AS storesNumber
FROM StoresTitlesSold
GROUP BY title

-- iv) Preço médio dos livros da view (da categoria business)
SELECT AVG(price) AS averagePrice
FROM TitlesBusiness

-- c)
SELECT store_name, concat(au_fname,' ',au_lname) as author
FROM (
	TitleAuthor JOIN StoresTitlesSold
		ON TitleAuthor.title = StoresTitlesSold.title
	)

-- d)
insert into TitlesBusiness (title_id, title, type, pub_id, price, notes)
values('BDTst1', 'New BD Book','popular_comp', '1389', $30.00, 'A must-read for DB course.')

-- Não teve sucesso pois a forma como os dados sao inseridos não é a correta, faltam alguns atributos...
-- Para alem disso estariamos a criar inconsistencia na view, pois o seu type é Business e tentamos adicionar 'popular_comp'
-- solucao:
CREATE VIEW TitlesBP(title_id, title, type, pub_id, price, notes) AS
SELECT title_id, title, type, pub_id, price, notes
FROM dbo.titles
WHERE titles.type LIKE 'business' OR titles.type LIKE 'popular_comp'