-- Pratica 9 - ex 9.3
-- Maria In�s e Gon�alo Matos P4G2 Maio 2020

-- a) 
-- i
CREATE UNIQUE CLUSTERED INDEX ssnIndex ON dbo.Company.Employee(ssn);

-- ii
CREATE NONCLUSTERED INDEX namesIndex ON Employee(Fname,Lname);

-- iii
CREATE NONCLUSTERED INDEX depEmpIndex ON Employee(Dno);
CREATE UNIQUE CLUSTERED INDEX depIndex ON Department(Dnumber);

-- iv
CREATE UNIQUE CLUSTERED INDEX ssnIndex ON Employee(ssn);
CREATE UNIQUE CLUSTERED INDEX worksOnIndex ON Works_on(Essn,Pno);
CREATE NONCLUSTERED INDEX projIndex ON Project(Pnumber);

-- v
CREATE UNIQUE CLUSTERED INDEX DependentIndex ON Dependent(Essn,Dependent_name);

-- vi
CREATE NONCLUSTERED INDEX projIndex ON Project(Dnum);
CREATE UNIQUE CLUSTERED INDEX depIndex ON Department(Dnumber);
