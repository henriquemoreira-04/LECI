-- Pratica 9 - ex 9.2
-- Maria Inês e Gonçalo Matos P4G2 Maio 2020

CREATE TABLE mytemp (
		rid BIGINT /*IDENTITY (1, 1)*/ NOT NULL,
		at1 INT NULL,
		at2 INT NULL,
		at3 INT NULL,
		lixo varchar(100) NULL
);

-- a)
CREATE UNIQUE CLUSTERED INDEX ridIndex ON mytemp(rid);


-- b) correr na bd local e obter tempo
Inserted      50000 total records
Milliseconds used: 115050 (00:01:54)

--c) usar um de cada vez e voltar a correr o script de b
CREATE UNIQUE CLUSTERED INDEX  ridIndex_c1 ON mytemp(rid) WITH (FILLFACTOR = 65, PAD_INDEX = ON)
Inserted      50000 total records
Milliseconds used: 105524 (00:01:45)

CREATE UNIQUE CLUSTERED INDEX  ridIndex_c2 ON mytemp(rid) WITH (FILLFACTOR = 80, PAD_INDEX = ON)
Inserted      50000 total records
Milliseconds used: 136603 (00:02:16)

CREATE UNIQUE CLUSTERED INDEX  ridIndex_c3 ON mytemp(rid) WITH (FILLFACTOR = 90, PAD_INDEX = ON)
Inserted      50000 total records
Milliseconds used: 133970 (00:02:13)

 -- d)
 -- nao permite fazer isto: ALTER TABLE mytemp ALTER COLUMN rid IDENTITY (1, 1);

CREATE TABLE mytemp (
		rid BIGINT IDENTITY(1,1) NOT NULL,
		at1 INT NULL,
		at2 INT NULL,
		at3 INT NULL,
		lixo varchar(100) NULL
);

/*
Inserções começaram a dar o erro
Cannot insert explicit value for identity column in table 'mytemp' when IDENTITY_INSERT is set to OFF.
*/

-- e) criar apenas no final pra teste
CREATE NONCLUSTERED INDEX at1Index ON mytemp(at1);
CREATE NONCLUSTERED INDEX at2Index ON mytemp(at2);
CREATE NONCLUSTERED INDEX at3Index ON mytemp(at3);
CREATE NONCLUSTERED INDEX lixoIndex ON mytemp(lixo);

-- Tempos sem
Inserted      50000 total records
Milliseconds used: 178034 (00:02:58)

-- Tempos com
Inserted      50000 total records
Milliseconds used: 142220 (00:02:22)